# @axis-iam/vertex-react

## Discovered Authentication Options

`IamProvider` discovers methods and registration capabilities from `/api/v1/apps/{clientId}/auth-methods`.
Provider IDs, labels and availability remain backend-owned; `useIdentityProviders` also preserves exact discovery
identities. Retired `IamConfig.authMethods`, `IamConfig.socialProviders` and `SocialProviderConfig` are not public
options. Passing retired options from untyped JavaScript throws `IamConfigurationError`, rather than enabling or
renaming a provider. The browser `clientId` and resource `audience` remain supported and distinct.

Host presentation stays configurable through `appearance`, `darkAppearance`, `colorScheme`, `locale`,
`localization`, component container styles and `renderProviderButton`; custom buttons must use the supplied
provider ID/action and respect disabled state.

## Explicit Server Sessions

Choose a mode deliberately. `sessionMode: 'oauth_tokens'` (default) uses public-client OAuth and memory-default tokens.
`sessionMode: 'server_session'` requires a public `SessionTransport`; it creates no TokenManager and never switches
to tokens on errors. A customer BFF can implement the finite `SessionRequest` union directly; arbitrary URL/header
proxy requests are not part of that interface.

```tsx
import { CookieSessionTransport, IamProvider, SignIn, useServerSession } from '@axis-iam/vertex-react'

const transport = new CookieSessionTransport({ origin: window.location.origin, basePath: '/console' })
// Construct once per host, outside render. SSR may construct with its explicit canonical origin.
<IamProvider sessionMode="server_session" sessionTransport={transport}
  clientId="configured-client" issuerUri="https://iam.example.com" redirectUri="/login">
  <SignIn mode="embedded" />
</IamProvider>

function WorkspaceControl() {
  const { view, actions } = useServerSession()
  // Memberships come from actions.listWorkspaces(), never user-supplied authority.
  return <button onClick={() => void actions.selectWorkspace('selected-membership-id')}>
    Select workspace
  </button>
}
```

The adapter performs `GET /console/session/bootstrap`, uses same-origin Cookie credentials, no-store and
redirect refusal. Writes use that session's `X-CSRF-Token`; the browser supplies Origin. It accepts no bearer,
forwarded host, upstream target or custom headers. Safe authenticated views bind profile, permissions, owner,
version and original expiry. Session restoration, account/Workspace changes, logout and deadlines invalidate
old work. Failures are visible; a failed read is not an empty authenticated view. The host registers the BFF's
callback, not a browser verifier. Provider HTML returns to `/login` or `/settings/security` after the BFF consumes
its private callback; `sessionProviderReturnUri` may name the exact same-origin identity return for a customer BFF.

Embedded, Dialog and `useAuthFlow` use the same Cookie login/challenge/Provider/MFA/complete/cancel actions.
On reload or Provider return, MFA is restored through bootstrap, without URL proof or tab storage.
`useAuth().login()`/redirect SignIn navigates to the explicitly configured same-origin `sessionLoginUri`
(default `/login`), whose host page mounts the Embedded/Custom form. Existing Hosted OAuth remains available for
oauth_tokens. The connected-application Hosted endpoint requires explicit mounting as described below.

For the delivered connected-application C0 routes, import `ConnectedAppSessionTransport` from `@axis-iam/vertex`
and pass it to `IamProvider` with `sessionMode="server_session"`, `sessionLoginUri="/auth/login"` and
`sessionProviderReturnUri` equal to the clean app landing configured as BFF `successRedirect` (for example `/signed-in`).
The registered IAM callback remains `/auth/callback`; the BFF consumes it before redirecting to that clean landing.
Its default prefix is `/auth`; Console's
`CookieSessionTransport` keeps `/console`. `startAuthorizationFlow`/redirect SignIn first restores bootstrap so the
Hosted GET has its required prelogin binding. Mount the Node Express `createBff` or Nest `mountBff` at the same prefix.
The default `sessionLoginUri="/login"` remains available for an application-owned form page.

For manual `completeMagicLink`, `sessionMagicReturnUri` identifies the exact same-origin browser fragment landing
(defaults to `redirectUri`). The Node `/auth/callback` fragment bridge normally handles this transient step itself,
clears the fragment before sending its CSRF action and returns to the ordinary application form/MFA landing.

The connected-application transport supports Hosted and the existing Embedded, Dialog and `useAuthFlow` Headless
entries, required MFA, Provider return and the limited registration/EMAIL recovery contract. It explicitly rejects
Console-only account/Workspace/step-up extensions; the existing Console transport retains them. UI method availability
still requires concrete IAM capability and policy. Server-session token APIs continue to throw.

`getAccessToken`, `refreshToken`, browser code exchange, OIDC logout URL and token-specific APIs throw
`UNSUPPORTED_OPERATION`. `logout` uses the BFF and immediately invalidates local ownership; a remote refusal
is reported, not claimed as confirmed. AccountCenter/profile/security/sessions/ConnectedAccounts use safe Cookie
actions without Access Tokens. Identity state distinguishes `{ref,...}` from OAuth `{id,...}`; use
`actions.transfers()` to discover current participant transfers, then `useIdentityOperations().actions.reopen(ref)`.
Never substitute another browser's ref or raw operation/control ID.

`useServerSession().actions` also exposes purpose-bound `startStepUp(trigger, reason)` (TOTP/WebAuthn),
enrollment reauthentication, TOTP/WebAuthn enrollment, credential removal and recovery-code actions. A successful
step-up returns a purpose ref consumed by the matching sensitive action; it is not a reusable authentication flag.
`generateRecoveryCodes()` returns `{codes,count}` only to its caller. Show/save those intentional one-time user
materials within the host's dedicated recovery UI; never put them in generic session/query state, logs or storage.
Enrollment secrets/QR are likewise caller-owned, not session authority.

The console registration adapter accepts the strict `{identifier:{kind:"EMAIL"|"USERNAME",value},password}` body,
with one optional `registrationGrantToken` or `registrationAccessCode`. It never previews or consumes the grant early.
Server-session grant-preview and organization-invitation adapters remain explicitly unsupported. Browser Magic callback
completion uses the delivered `/console/session/login/magic` DTO; the server-owned fragment bridge normally handles
the callback and returns to `/login`, where bootstrap restores the safe session or MFA continuation. Provider registration uses the delivered strict authorize
DTO independently of that registration adapter. Impersonation destination wire is outside this frozen handoff.

### Provider Registration DTO

Core `authorizeProvider(providerId, proof?)` accepts mutually exclusive `registrationGrantToken` (1-2048) or
`registrationAccessCode` (1-128). React accepts typed `registrationGrant` in Provider options or
`useAuthFlow().actions.startProvider(providerId, registrationGrant?)`; supply it either in hook options or the action,
not both. Embedded/Dialog access-code input uses this exact DTO. Hosted signup retains the actual server form/grant
contract. Grants are never persisted in the navigation store and do not bypass Provider identity or required MFA.
`ORG_INVITATION`, mixed/empty/oversized fields fail before transport. Sign-in without a grant remains unchanged.

React components, providers and hooks for Axis Vertex. React and React DOM are peer dependencies. Server rendering
helpers use `JwtVerifier` from `@axis-iam/vertex/server` or the Express/Nest adapters. The decode-only React server subpath has been removed.

This README describes the current **unpublished candidate**, not an npm beta release. Package version `0.1.0` does not identify the new APIs; older preview tarballs remain separate. See the [candidate and integration map](../../docs/current-integration.md) before choosing matching reviewed artifacts.

## Authentication entries

Wrap each entry in `IamProvider` with the Application Client's `issuerUri`, `clientId` and registered `redirectUri`. Browser tokens stay in memory unless the host explicitly chooses supported persistence. Primary sign-in in Embedded, Dialog and Custom uses controlled authentication transactions followed by Authorization Code + S256 PKCE. Provider sign-in uses the same controlled transaction. Hosted retains its branded server authorization route and shares the finite navigation store. Explicit server_session uses a separate Cookie/CSRF transport; it never stores browser OAuth control or tokens.

| Entry | Usage | Completion |
| --- | --- | --- |
| Hosted | `<SignIn />`, or `useAuth().login()` | Authorization Code + S256 PKCE; call `handleRedirectCallback()` on the configured callback page |
| Embedded | `<SignIn mode="embedded" />`, `<SignUp mode="embedded" />` | Shared primary transaction flow, with discovered methods and policy |
| Dialog | `<AuthDialog open={open} onOpenChange={setOpen}>…</AuthDialog>` | One active Embedded form by default; `mode="redirect"` launches Hosted |
| Custom | `useAuthFlow(options)` | Public state/actions; the host renders its own UI |

Hosted callback handling validates state, consumes the saved PKCE verifier and scrubs callback parameters. Treat the callback result/error explicitly. Do not store authorization codes, proofs, passwords or tokens in app URLs, logs or analytics. Use `config.redirectUri` to configure navigation; `SignIn` does not expose a `redirectUrl` prop. `onSuccess` is an explicit completion callback, not a navigation promise.

Dialog has a single title and a small localized intent switch when registration policy permits it. Switching intent, closing, Escape and backdrop immediately discard local ownership and request server cancellation. Cancellation failure remains visible and rejects the action; Dialog stays open on refusal. Unmount discards local ownership. An explicitly saved navigation record may survive unmount until its original deadline. Reopening returns to `initialView`. Desktop and mobile framing, focus trapping/return, locale, Appearance and light/dark/system themes are inherited from the provider. It does not preserve hidden forms.

### Public transaction flow

```tsx
import { useAuthFlow } from '@axis-iam/vertex-react'

function AppOwnedSignIn() {
  const { state, actions } = useAuthFlow({
    onSignInSuccess: user => showAccount(user),
    onSignUpSuccess: profile => showVerificationInstructions(profile),
    onError: error => reportSafeErrorCode(error.name),
  })
  // Render according to state.step. These actions are called from host-owned forms:
  // actions.continueWithIdentifier({ kind: 'EMAIL', value: email })
  // await actions.submitPassword(password)
  // if state.step === 'mfa': await actions.verifyMfa(authenticatorCode)
  return <p role="status">{state.step}</p>
}
```

The complete [CustomAuth example](https://github.com/axis-iam/vertex-sdk-js/blob/develop/packages/react/examples/CustomAuth.tsx) uses only public package imports. The package consumer runner compiles and renders that exact example from packed core/react tarballs.

`useAuthFlow(options?: UseAuthFlowOptions)` returns `{ state, actions }`. Options are `initialIntent: 'sign-in' | 'sign-up'`, `registrationGrant`, `onSignInSuccess`, `onSignUpSuccess`, `onError` and `autoProviderCallback` (default true). Exported contracts include `UseAuthFlowResult`, `AuthFlowState`, `AuthFlowActions`, `AuthFlowIntent`, `AuthCredentialMethod`, `AuthFlowStateError` and `RegistrationOperation`.

State steps are `loading`, `unavailable`, `identifier`, `method`, `mfa`, `sign-up`, `verification`, and `success`. Narrow on `step` before reading branch fields. Common readonly fields expose capabilities, resolved password/registration policy, intent-filtered providers, `pending`, typed `error`, `retryAfterSeconds`, verification email and `verificationResendDeadline`. State exposes the original transaction/challenge deadlines and `cancellationUnconfirmed`. It never contains passwords, OTP values, transaction control, PKCE verifier or registration secrets. Profile/roles metadata is not an authorization source.

| Actions | Contract |
| --- | --- |
| `continueWithIdentifier`, `selectMethod` | Synchronous selection with typed validation. Method changes discard local ownership and report cancellation failure in state. |
| `setIntent`, `back`, `cancel`, `reset` | Promise-returning cancellation; await or consume rejection. State resets immediately, with `cancellationUnconfirmed` on failure. |
| `submitPassword`, `sendCode`, `verifyCode`, `sendMagicLink`, `completeMagicLink`, `verifyMfa` | Controlled primary transaction actions; `verifyMfa(code, "TOTP" | "RECOVERY_CODE")` continues the same transaction. `completeMagicLink(callbackUrl)` consumes the exact AUTH_PROOF fragment with original-tab control and typed identifier. |
| `signUp({identifier, password, registrationGrant?})` | Returns a profile result through state/callback. It does **not** authenticate. Password constraints come from policy. Host UI owns confirmation matching. |
| `resendVerification()` | Available only for pending email verification; obeys the discovered verification resend interval. |
| `startProvider(providerId)` | Calls the original transaction `/authorize` with `{providerId}`, saves its pending control/PKCE binding, and returns the validated provider URL. Host owns current-attempt navigation. |
| `signInWithProvider(providerId, { registrationGrant?, timeoutMs? }?)` | Shared popup flow for user actions; opens the window, awaits the exact return, consumes it and closes all window/timer resources. Default timeout is ten minutes; a shorter positive timeout may be supplied. |
| `resumeProviderCallback(url)` | Consumes exact original-tab binding, GETs transaction state and restores MFA or exchanges the returned code once. |

Async actions reject typed Core `AuthenticationTransactionError`, `IamApiError`, `IamNetworkError`, `IamConfigurationError` or `AuthFlowStateError`, record the failure in state and call `onError` once. The same pending action/input shares one promise; a conflicting action rejects without another request. Only an uncertain `/complete` receives one automatic reconciliation with identical bytes and its original key. Password, OTP, MFA, messages and a sent token exchange are never automatically replayed. A canceled or replaced attempt rejects `SessionInvalidatedError` and cannot write tokens/state, emit callbacks or navigate. Hosts should consume that cancellation without displaying an authentication failure. Guard host-owned promise `then`/`finally` work by mount and attempt ownership; clear secrets before leaving the form.

Password, email OTP, SMS, magic link and provider controls are available only when discovery reports readiness for the current intent. Registration requires both capability and policy approval. `INVITE_REQUIRED` requires an accepted explicit `EMAIL_LINK`, `ACCESS_CODE` or `ORG_INVITATION` proof. Supply the proof either in options or in `signUp`, never both. Provider signup filters `availableForSignup` and posts the delivered mutually exclusive registration grant token/access-code fields. A grant gates registration, never substitutes for Provider identity or MFA. `ORG_INVITATION` is never reinterpreted. No production SMS or external provider credentials are supplied by the SDK.

Primary authentication posts to `/api/v1/auth/transactions` with `entryMode: "CUSTOM"`, strict scopes, random state, S256 challenge and an `openid` nonce when applicable. Challenges, PASSWORD/EMAIL_OTP/SMS_OTP/EMAIL_MAGIC_LINK proofs, TOTP or recovery-code MFA, and completion share the private `Authentication-Transaction` header. Proof, MFA and completion requests have canonical random 32-byte base64url idempotency keys. Lost proof/MFA responses require the same input/key; a changed input is rejected until status or cancellation resolves ownership. No primary action uses a Direct login or verification fallback.

`sendMagicLink()` explicitly saves only short-lived transaction control and PKCE binding in tab `sessionStorage`; ordinary sessions remain memory-only unless separately configured. The exact callback fragment contains `kind=AUTH_PROOF`, `auth_transaction_id`, `method=EMAIL_MAGIC_LINK`, `state`, and `proof`. It contains no control or verifier. Return to the original tab, re-enter the original typed identifier, select Magic link, then submit or call `completeMagicLink(window.location.href)`. The backend binds the proof to its original target. A new tab without saved control, wrong redirect/state/transaction, or expired record fails before proof submission. The action scrubs the current URL fragment after consuming it. Recovery from a lost in-memory proof or token-exchange uncertainty requires fresh sign-in.

Challenge expiry and resend cooldown come from the transaction challenge response, bounded by the original parent deadline. Server rejection and numeric 429 `Retry-After` remain observable. Resending invalidates the earlier proof on the server. Local timers never renew transaction or token deadlines.

Completion returns an authorization code and state, followed by one request to the discovered token endpoint. `TOKEN_EXCHANGE_UNCERTAIN` means a sent code exchange may have succeeded: start a new login. `TOKEN_REFRESH_UNCERTAIN` is terminal after a sent refresh has an unknown result; the SDK clears that session and never retries the old refresh token. Discovery failure before transport remains distinct.

Authentication becomes ready only after both `/api/v1/auth/me` and `/api/v1/auth/me/permissions` load under the new owner. View errors remain explicit. Access Tokens are never decoded for identity, permissions or expiry. Browser persistence uses version 6 with tokens, original response-derived deadline and owner; it does not persist safe views or permissions.

OAuth logout clears local state before revoking the current session via `/api/v1/auth/logout` with no Direct RT body; optional redirect uses discovered OIDC end-session. Refresh uses only discovered OAuth form transport. Legacy Direct session storage is rejected and cleared; no Direct refresh/logout alias remains. Complete real-backend combined smoke remains separate. Server-only WebAuthClient retains its own supported contract.

### Provider return and signed-in confirmation

Anonymous Provider sign-in uses `POST /api/v1/auth/transactions/{id}/authorize` with exact `{providerId}` and original transaction control. The normal code/state callback and `kind=AUTH_CONTINUATION&auth_transaction_id&state` query callback are mutually exclusive. Embedded/Dialog and Custom share `useAuthFlow` automatic return handling; no extra completion click is required. Use `actions.signInWithProvider(id)` for a popup, or navigate to `actions.startProvider(id)` and mount the same hook on the exact callback route. A required MFA return stops at the actual MFA form without storing tokens. Low-level `handleRedirectCallback()` remains available and returns `{status:"continuation",transaction,view}` for hosts explicitly owning the route. Callbacks are scrubbed and consumed once. A continuation never acts as proof or a login ticket.

`PendingAuthorizationStore` from Core is the single tab-local store for CUSTOM Provider/Magic navigation and existing HOSTED OAuth. It binds issuer/client/exact redirect/entryMode/flowOwner/state/verifier, optional transaction/control and absolute expiry. Hosted's local context is bounded to ten minutes; CUSTOM never exceeds its original transaction deadline. Unknown fields, ordinary tokens, expired records, duplicate callback fields, alternate redirects and wrong state fail closed. No legacy `iam_pkce_verifier`/`iam_oauth_state` or localStorage fallback is read. Storage refusal prevents navigation. Explicit logout/cancellation and account changes discard matching pending control.

Authenticated identity Provider confirmation is not anonymous login. Call `useIdentityOperations().actions.openProvider(purpose, exactRedirect, methodId?)` directly from a user gesture. It opens the separate window **before** asynchronous PKCE/authorize work, keeps the current token and verifier in the original window, and reports popup blocking without top-level fallback. On return, the original host calls `actions.providerCallback()`: the SDK reads only that window's exact callback location, checks operation/authorization IDs and `identity_operation=proof_pending`, performs protected GET, then consumes the existing PKCE-bound proof endpoint. Callback query, popup close and GET alone never satisfy proof. This also applies to a TRANSFER recipient using `TRANSFER_COUNTERPART`. Closing/canceling/unmount/expiry/account replacement rejects late work; `cancelProviderWindow()` explicitly closes local confirmation without claiming remote cancellation. Custom hooks close their popup on unmount. No window message supplies tokens or a generic grant.

Server sessions use the explicit public SessionTransport described below. Browser OAuth persistence is a separate mode and is never enabled for Cookie navigation continuity.

### Reproducible auth-entry consumer

`node packages/react/visual-smoke/run-auth-entries.mjs --fixtures-only` builds packed consumers and uses controlled transaction routes. Its result is fixture proof. Live mode is explicitly disabled until the complete backend/Hosted/Provider candidate is delivered; obsolete Direct/MFA/Redis live probes have been retired. The session-lifecycle runner now uses OAuth token refresh only; live password admission is disabled rather than calling the retired Direct issuer.

`node packages/react/visual-smoke/run-auth-recovery.mjs` consumes already-built Core/React dist as real tarballs in a new independent consumer. It verifies types/ESM/CJS and actual browser automatic returns, busy/recovery, MFA, stale/duplicate callbacks and context/tab isolation against task-owned loopback protocol endpoints. It scans/binds archive sources and releases its browser/services in `finally`. Its result never claims real third-party or external-host integration.

### Application branding in Embedded, SignUp and Dialog

Embedded `<SignIn>`, embedded `<SignUp>` and embedded `<AuthDialog>` share one scoped
branding view. They request `GET /api/v1/apps/{clientId}/branding?ui_locales=en&intent=login`
(or `zh-CN` / `signup`) using the resolved `IamProvider` locale and current flow intent.
The server localizes system title/subtitle/button/footer copy and preserves authored
copy verbatim, including explicit empty strings and English strings in a Chinese UI.
Switching between login and signup requests the matching intent. No English-text
matching or SDK translation of authored branding occurs.

The view honors `showLogo` plus `logoUrl`, title/subtitle, password/OTP login submit
text, signup submit text and footer. Busy/verification/continue/provider actions keep
their state-specific localized labels. Empty button text is preserved as configured;
Application authors should provide an accessible action label. Branding loading and
failure are visible; failure offers a retry and authentication stays available with
SDK defaults. A failed request never reports a successful branding load. Changing
client, locale or intent clears the previous branding immediately and ignores obsolete
responses. Requests have the transport timeout; obsolete results are ignored rather
than applied (a request already sent may finish).

| Token | Light | Dark |
| --- | --- | --- |
| Primary action | server `primaryColor` | same server accent |
| Text and background/surface | server `textColor` / `backgroundColor` | SDK readable dark semantic defaults |
| Link/focus | server `secondaryColor` | SDK readable dark focus default |
| Logo and authored copy | server fields | same fields |

Light token priority is component `appearance` → provider `appearance` → applicable
server tokens → SDK defaults. Provider `appearance.primaryColor`, font and radius also
carry into dark; light-only provider surface/text colors do not. In dark, explicit
provider `darkAppearance` overrides brand accent/default dark tokens, and component
`appearance` overrides those explicit dark tokens. Supply readable foreground/surface
pairs when overriding. `system` follows the OS using these same two palettes. Dark
does not copy a configured light background/text or a potentially dark secondary link
color onto a dark surface. Host component overrides remain deliberate and can override
any token in either scheme.

`faviconUrl`, `backgroundImageUrl`, `loginLayout`, `socialButtonPosition` and
`defaultLocale` are available as data, not document-wide styling instructions. The
SDK does not inject Hosted CSS, customCss, favicon, remote fonts or full-page layouts.

### Opt-in branding for Custom hosts

The public root exports `useBranding(intent?: BrandingIntent): UseBrandingResult`,
`BrandingConfig`, `BrandingIntent` (`'login' | 'signup'`) and `BrandingFetchError`.
Call the hook inside `IamProvider`, alongside `useAuthFlow`:

```tsx
const flow = useAuthFlow()
const { branding, isLoading, error, retry } = useBranding(
  flow.state.intent === 'sign-up' ? 'signup' : 'login',
)
// Host renders loading/error/retry, then chooses logo, copy and style tokens.
// error instanceof BrandingFetchError; code = 'BRANDING_FETCH_FAILED'; status may exist.
```

The result contains nullable `branding`/`error`, `isLoading`, and an explicit `retry`.
Transport/discovery/malformed-response errors are typed; their public message is
sanitized. A missing/invalid `showLogo` or incorrectly typed rendering field rejects
the payload. Nullable/absent optional server strings remain optional data. The hook
never applies styles or changes the document. Headless `useAuthFlow` itself does not
fetch branding. [CustomBranding](examples/CustomBranding.tsx) demonstrates opt-in host
rendering; the host owns its loading/error copy, accessible labels and theme mapping.

### Registration access-code policy

Embedded SignIn/SignUp and Dialog share the policy-driven registration form. OPEN
with ACCESS_CODE shows an optional input: blank uses ordinary open registration;
a supplied code uses the existing grant contract. INVITE_REQUIRED with no preset
registrationGrant requires the allowed access-code input. A preset email-link,
organization invitation or access-code proof stays owned by the public flow; the
form does not add a competing proof. Disallowed codes, disabled registration and
loading/unavailable policy never show or submit old code. Intent/policy changes
clear entered codes; typed server failures keep them editable. Custom hosts use
state.policy/capabilities gates; actions.signUp already rejects missing required,
disallowed and conflicting proofs before transport.

### Application identity operations

Password login accepts an explicit `LoginIdentifier` (`EMAIL`, `USERNAME`, or `PHONE` with an explicit region when needed). Registration accepts only the effective allowed EMAIL/USERNAME kinds, never PHONE. Text never changes the selected kind. Email registration returns a registration operation, not a User or session. Use `client.identity.startRegistration`, `getRegistration`, and `registrationAction` (`challenges`, `complete`, `cancel`). The Registration-Control secret stays in memory and is separate from the email code. If it is lost, restart and choose your own password. Only a completed operation offers sign-in; completion does not sign in automatically.

`client.identity` exposes identifier/version facts, durable create/get/reauthenticate/challenge/authorize/providerCallback/complete/cancel/confirmTransfer actions and independent recovery authorization/status/challenge/completion/cancellation. `useIdentityOperations` exposes the same shared state to Custom and AccountCenter. Preserve the operation ID when a cancellation is uncertain and GET it before retrying. Provider confirmation uses PKCE and a separate window so the initiating context keeps the verifier in memory. The callback page contains no token handling; return to the initiating window to finish confirmation. A receiving account opens the operation ID in its own session and reauthenticates before ACCEPT; REJECT ends the transfer.

When a create response is lost, `state.uncertainCreate` retains the original typed
`request` (including `expectedLoginMethodVersion`) and `idempotencyKey`.
Custom hosts should disable edits and other operation actions and offer
`actions.retryCreate()` to recover that exact request. The store also rejects
changed payloads, changed keys and other operation actions with `CREATE_UNCONFIRMED`
until recovery succeeds or the server definitively rejects creation. Repeating
`actions.create()` with the same input and key is also supported.

```tsx
const { state, actions } = useIdentityOperations()
if (state.uncertainCreate) {
  return <button disabled={state.pending} onClick={() => {
    void actions.retryCreate().catch(showOperationError)
  }}>Recover original request</button>
}
```

Known pre-creation validation errors such as `INVALID_IDENTIFIER` clear the
attempt so the user can correct the input and deliberately submit with a new key.
For `STALE_LOGIN_METHOD_VERSION`, Custom hosts must reload identifier/login-method
facts before the next submission; ConnectedAccounts does this automatically.
Transport errors, server failures, malformed responses and unknown rejection codes
retain the attempt. This recovery state is held in memory and cleared on session
change. Keep the initiating window open: a full page reload cannot recover a
creation whose operation ID was never received, including when token storage is
explicitly set to sessionStorage.

`listAccountLoginMethods` returns `{ loginMethodVersion, methods }`; capabilities and unavailable reasons come from the server. Profile PATCH accepts displayName/avatarUrl only; username changes use identifier operations. The old link-ticket/exchange/direct DELETE protocol and hooks are retired. Users without a primary email have a nullable email projection.

## Safe session views

`useAuth().user` and `isAuthenticated` become available only after both
`GET /api/v1/auth/me` and `/me/permissions` succeed. `user.authenticationContext`
contains the explicit Application, client, session, nullable Workspace/Organization,
authentication time/methods, assurance, and impersonation context. Nullable email,
empty roles/permissions and a Workspace requiring selection are valid. Metadata is
for display only. The former `user.raw`, JWT payload decoder and React `/server`
guards are removed without aliases.

`useAuth().sessionView` exposes `status` (`anonymous`, `loading`, `ready`, `error`,
`expired`), `error`, and `expiresAt`. While either required view is loading or
fails, user and permissions are unavailable. HTTP 401 ends the local session;
403, malformed context and dependency errors reject the action and expose an error.
Retry `client.fetchPermissions()` through `useIamContext()` after resolving the
failure. OAuth callback and Custom `useAuthFlow` success wait for both views.

Token deadlines come only from OAuth response `expires_in`. Access Token bytes are
never decoded for identity, roles, assurance or expiry. Refresh reloads both views
and checks User/Application/client/session ownership; late responses from a previous
login cannot replace a current session. Storage remains memory by default. Explicit
`tokenStorage="sessionStorage"` uses version 6: tokens, original absolute deadline,
provenance and owner only. Reload fetches new views without renewing the deadline.
Prior storage versions are rejected and removed; sign in again after upgrading.

`useStepUp().start('PASSWORD_CHANGE', reason?)` calls the actual `/step-up/start`
endpoint and returns `challengeId`, `availableMethods` and `verifyTotp(code)`.
The server owns the purpose/session-bound grant and consumes it on the sensitive
operation. Assurance and a successful refresh never establish a local grant flag;
there is no `isSteppedUp`. WebAuthn remains available through the existing WebAuthn
API. `useImpersonation()` reads the API's exact `impersonationId`; ending it clears
the local session after server confirmation and rejects stale account responses.

This migration consumes stable `/me` and delivered primary/Provider CUSTOM transaction contracts. Hosted retains branded authorization; server_session consumes the delivered finite BFF contract. Impersonation destination continuation is not inferred from unrelated active producer work. Protocol-fixture evidence is not complete-backend integration proof.

### Hosted OpenID nonce and current public metadata

Public auth-methods/auth-policy no longer contain the retired email verification mode.
Email registration always completes its verification operation before activation; readiness,
signup grants, access-code gates and resolved password constraints still apply.

`startAuthorizationFlow()` generates independent random state, S256 verifier and (for `openid`)
nonce. The nonce joins the bounded, exact issuer/client/redirect/owner pending record in
sessionStorage and survives navigation. `handleCallback` consumes that record before the
single code exchange and validates the ID Token with issuer JWKS, ES256 signature, issuer,
client audience, lifetime, subject and the expected nonce. Missing/mismatched nonce or ID Token
fails with `OIDC_ID_TOKEN_INVALID` before storing any OAuth session. Access Tokens remain opaque;
profile and permissions still come from the authoritative APIs. Expired/cancelled/consumed
records require a new sign-in; a stale callback cannot replace a newer pending owner. Existing
pending OpenID records without nonce must restart sign-in. Non-OpenID scopes use OAuth-only
code exchange without inventing an ID Token requirement. Dispose preserves navigation pending
state; explicit logout discards it and invalidates local ownership.
### Identifier Capabilities And Account Changes

Embedded, Dialog and `useAuthFlow` consume the public auth-methods response's
`identifierMethods: Array<{ kind: 'EMAIL' | 'PHONE' | 'USERNAME'; methods: Array<'PASSWORD' | 'EMAIL_MAGIC_LINK' | 'EMAIL_OTP' | 'SMS_OTP'> }>`
and the resolved `defaultLogin:{identifierKind,method}`, nullable `defaultIdentifierKind`,
and effective `allowedSignupIdentifierKinds`. The resolved pair must match the first ordered identifier/method; Provider-only applications return an empty set and a null default.
Missing, duplicate or contradictory capabilities fail closed. The unavailable
view offers Retry (`actions.retryOptions()` for Custom); there is no guessed
kind or account-existence probe. `auth-policy.defaultLogin` is only a preference and is never used to invent an available method. The strict parser validates the resolved default before the ordered list is used.

The shared form shows compact identifier segments only when multiple kinds are available,
with the typed field above ordered credential choices. Single choices hide their switchers.
Changing credential method preserves the identifier (including PHONE country/local number)
but clears password/OTP. Changing identifier kind clears its draft, region and proof inputs.
User choices never reorder the server list. OTP enters a separate verification view only after
a successful send; `state.phase` exposes `credentials`, `code`, or `magic-link` for Custom.
Cooldown/429 and expiry use server deadlines; Change/Back cancel the old challenge. A magic
link waits for a real callback rather than an "already clicked" authentication shortcut.
EMAIL and USERNAME registration are independent, gated by the effective allowed set;
USERNAME never fabricates an email. An empty signup set leaves existing login/binding alone. PHONE password support does not depend on SMS delivery readiness.
Appearance, host fonts, brand copy, logo visibility and EN/zh-CN localization
remain host-controlled through the existing APIs.

PHONE sign-in uses a country/region selector (localized name and calling code)
and a local-number field. No country is selected from locale. Pasting a valid
international number synchronizes both fields; unresolved shared-code services,
unknown numbers and country mismatches are rejected locally. Changing country
clears the draft. Embedded and Dialog submit normalized E.164
`{ kind: 'PHONE', value: '+8613800138000' }` without `region`.
Custom/headless keeps its existing typed-identifier contract: hosts own any
country-selection UI and must supply valid E.164 without `region`, or a local
number with the explicit region. `examples/CustomAuth.tsx` has no duplicate
region form and retains the public E.164 path.

Registration verification has one primary action, a text resend/cooldown helper,
and a separate text cancellation action. Resend failures preserve entered codes;
cancellation uncertainty retains the original registration and offers a status
refresh. A live registration must complete or be explicitly cancelled before
`reset`/`setIntent` can discard its view.

Account profile email and its verification badge come from the active primary
EMAIL identifier, not the legacy profile `emailVerified` boolean. Unknown
verification is not shown as unverified; no primary email means no email badge.
Managed identifiers show their actual source, and unavailable provider names are
not substituted with technical IDs.

Connected-account changes use one protected dialog (the existing AccountCenter
dialog when embedded). **Continue later** closes the view, clears password/code
inputs and preserves the same operation. It does not call cancel. **Cancel
operation** calls the server; an uncertain response retains the reference and
requires status reconciliation before submitting more proofs. Technical
references and exact expiry are in expandable details, not the main heading.
Custom integrations can still use `useIdentityOperations().actions.reopen(ref)`
when they already hold an authorized operation reference; the prebuilt view no
longer asks ordinary users to paste an operation ID.

### Headless Capability Consumption

Core exports `parseAuthCapabilities`, `AuthCapabilities`, `DefaultLogin`, `IdentifierMethods`,
and `SignupIdentifierKind`. React re-exports the types and exposes `useAuthFlow` public actions
without requiring any prebuilt UI. `examples/CustomAuth.tsx` uses only public imports and the
same authoritative capability/default/registration state. PHONE hosts may reuse the pure
`phoneCountries`, `parsePhoneIdentifier` and `normalizePhoneIdentifier` helpers; no country is
inferred from locale. `allowSignUp` only controls presentation; it cannot enable server-disabled
registration and is not a substitute for the effective allowed set.

### Purpose-specific identity ranges

Embedded and Dialog use `capabilities.identifierRestrictions.login.phone.allowedRegions`; a
signup-only restriction does not narrow existing phone sign-in. Headless Custom consumers may
pass that same value to `phoneCountries(locale, allowedRegions)` and to the optional third
argument of `normalizePhoneIdentifier(value, region, allowedRegions)`. Binding consumers use
`identifierRestrictions.signup`, retain existing identifier facts, and handle the stable
`IDENTIFIER_RANGE_REJECTED` error. Registration uses `REGISTRATION_IDENTIFIER_REJECTED`.
No browser consumer receives an email-domain allow-list. The server rechecks current policy
when accepting/consuming proofs; these UI helpers do not grant permission or revoke sessions.

### Account Security: Embedded, Dialog, AccountCenter And Headless

`AccountCenter` has six sections: `profile`, `methods`, `password`, `security`,
`sessions`, `permissions`. Use `initialSection="security"` for a direct entry;
`securityProps` forwards supported panel customization. `AccountSecurityPanel`
is the embedded surface; `AccountSecurityDialog` wraps the same content/store in
protected modal focus and exact server cancellation. Do not mount competing
editors for one operation. An uncertain cancellation stays open for status recovery.
The permissions section shows localized role, resource/action, and active
organization-context summaries without asking end users to enter permission
codes. `AccountPermissionsPanel` keeps its permission-check API; its raw-code
checker is available only when a standalone developer surface opts in with
`showPermissionChecker`.

All surfaces use the existing `IamProvider` `colorScheme="light" | "dark" | "system"`,
`appearance`, `darkAppearance`, `locale="en" | "zh-CN"` and `localization.security`.
Runtime theme changes do not alter the host document theme. Setup QR generation
is local; it does not send the enrollment URI to an image service. Existing
WebAuthn credentials can confirm an operation; this does not add WebAuthn enrollment UI.

`useAccountSecurity()` returns summary, action-specific capabilities, recovery-code
count, `state`, `actions`, `refetch`, loading and typed errors. Both `OAuthClient`
and `ServerSessionClient` expose the typed `MfaOperationClient` methods directly.
Shared actions include create/retryCreate/query, current password/email proof,
scoped TOTP/WebAuthn, provider authorization/callback, begin/complete/cancel,
`clearSensitive()` and `acknowledge()`. Custom hosts must render only the offered
proof options and action capabilities; public signup/login metadata is not an
identity-management permission grant.

```tsx
import { AccountSecurityPanel, IamProvider } from '@axis-iam/vertex-react'

<IamProvider clientId={publicClientId} issuerUri={issuerUri}
  redirectUri={registeredCallback} colorScheme="system" locale="en">
  <AccountSecurityPanel />
</IamProvider>
```

For BFF, explicitly configure `sessionMode="server_session"`, a finite
`sessionTransport` (for example Core's `CookieSessionTransport`) and
`sessionProviderReturnUri` equal to the actual same-origin BFF provider callback
path, with no query/hash. No OAuth redirect is required by the identity-provider
operation action in BFF mode; do not substitute a guessed settings page. OAuth
retains its registered exact callback and in-memory PKCE. Open provider actions
directly from a gesture. The MFA BFF callback posts `{}` after the server callback;
identity BFF uses GET because its server callback already exchanges the proof.
The BFF owns upstream operation IDs/verifiers; they are not SDK method parameters.

`examples/AccountSecurity.tsx` contains executable public-package examples for
OAuth, BFF, controllable theme, all three prebuilt entries and a Custom/Headless
editor, including offered proofs and safe receipt recovery. It uses no internal
imports, bare fetch or type assertions to bypass a missing public action.

Safety rules for Custom consumers:

- Lost create: retain `state.uncertainCreate` and invoke `retryCreate()` with its
  original request ID/version. Do not create another operation.
- Lost mutation/cancel: `state.uncertain` blocks mutation replay. Query the exact
  receipt; do not use `totpEnrolled=false` to infer that begin never ran.
- Missing setup material: cancel/query the original operation before a new setup.
  Missing recovery-code delivery: a committed set cannot be shown again; a fresh
  generation requires a new deliberate confirmation.
- Keep material/codes only in authorized ephemeral UI memory. `clearSensitive()`
  handles close/unmount, and owner changes/disposal/expiry clear operation memory.
  Never put password/OTP/QR/codes/verifiers into URLs, storage, logs or analytics.
- Present `result.sessionImpact === 'REAUTHENTICATE'` as success requiring sign-in,
  not as a failed write. Then `acknowledge()` clears local session state. Prebuilt
  `onReauthenticate(receipt)` lets the host choose the legal sign-in continuation.

Identity operations now expose authoritative `proofOptions` and typed `completion`
separately from the legacy string-map `result`. Their shared Headless state also
blocks unknown-result replay and supports current-account email/scoped factor
proofs. `actions.identifiers()` returns the authenticated `{loginMethodVersion,
items, management}` snapshot in both OAuth and BFF modes. `management.add` supplies
USERNAME/EMAIL/PHONE capabilities; each identifier supplies VERIFY/SET_PRIMARY/
REMOVE/REPLACE/TRANSFER capabilities. Render their exact `allowed`,
`unavailableReasons`, `requirements` and `replacementPrimaryIds`; do not select the
first verified identifier or infer permission from anonymous login/signup metadata.
`management.proofOptions` describes the available current-account confirmation;
the operation's proof options remain authoritative after creation. Missing or
contradictory management wire fails closed. Existing out-of-range identifiers may
still be verified/set primary/removed; new values are revalidated by the server.
Capability snapshots are not grants: every write rechecks ownership, policy,
version, proof and the last usable sign-in path.

For a new Provider LINK, `operation.providerTarget` is null until verified target
proof returns. Its `providerId`, nullable `maskedDisplayName`/`maskedEmail` and opaque
64-lowercase-hex `reference` come from the actual adapter-bound target, not the
provider directory or an existing connection. AccountCenter shows that returned
presentation and requires an explicit **Confirm connection**. A READY view without
a target cannot be completed by the shared Headless store. The reference is not a
proof or a new request field; completion still sends the declared `{proofs:[]}`.
Committed receipt/status retains the same target. Cancel/expiry/owner change and
acknowledgement clear the local presentation; unknown-result completion is recovered
with the exact operation GET, never an automatic mutation replay. No provider raw
subject, token, claims, PKCE verifier or opaque target reference is displayed or stored.

## Invitation journey entry

`OrganizationInvitationAccept` is independent of AccountCenter. Mount inside the same `IamProvider` throughout
login. It reads and scrubs URL `continuation` synchronously before I/O, then retains it only in component memory.
Alternatively pass `continuation` from a host that already scrubbed the URL, or `journeyRef` for an authorized
result read; do not pass both. The retired `token`, `onLoginRequired`, `useOrganizationInvitation`, and raw-token
preview/accept methods are no longer exported.

- Embedded: `<OrganizationInvitationAccept />`; existing-account/Provider authentication stays normal Client
  OAuth. Provider popups preserve the opener; verification still requires explicit invitation confirmation.
- Hosted: `<OrganizationInvitationAccept loginMode="hosted" />` opens ordinary Client login in a bounded popup.
  The registered callback route must be passive; click "I have signed in" in the opener. No top-level navigation
  fallback, proof storage, issuer Cookie, or continuation in Provider/OAuth parameters is used.
- Dialog: `renderLogin={() => <AuthDialog ... allowSignUp={false} signInProps={{providerNavigation:'popup'}} />}`.
- Custom: host-owned `useAuthFlow` markup can use exported `AuthProviderWindow` around ordinary `startProvider`
  and `resumeProviderCallback`. Keep its exact registered same-origin callback passive and close on unmount.
- Headless: `useInvitationJourney({continuation,ref})` exposes safe snapshots, explicit registration/verification,
  finite authentication/MFA, continue/confirm/cancel and authoritative result/status reads. It also exposes
  `startHostedLogin` / `completeHostedLogin` for proof-preserving ordinary login. Examples are in
  `examples/InvitationJourney.tsx`; all use published package exports.

The browser owns no BFF upstream context/token. `server_session` requires an explicit `SessionTransport`, a real
host prelogin/bootstrap and CSRF, plus the finite `/server` `InvitationBff` adapter or equivalent host routes.
The host can preserve its logical prelogin owner through first OAuth login, but must replace it when user,
Application or Client changes. BFF Hosted callbacks finish server-side and return to `config.redirectUri` with
no query/hash. A callback route must not independently consume the opener's public OAuth pending state.

The registration form uses the invitation's private finite context, not ordinary token storage. Password/OTP
inputs clear after submission. Successful registration leaves membership unchanged; the displayed current role
must be explicitly confirmed. Finite MFA verifies an already enrolled TOTP/recovery credential. For a genuinely new, SMTP-verified
invitation signup that requires MFA, the component offers only the server-permitted TOTP/WebAuthn first-factor
enrollment. TOTP setup is generated locally as a QR/manual key; WebAuthn requires user verification and the
registered Application origin. Setup material is delivered once and remains local to the initiating view,
not the journey store, BFF session, URL or browser storage. Completion establishes only invitation-bound MFA
proof: no ordinary session/token or organization membership. Explicit invitation confirmation remains separate.
Headless hosts use `enrollment`, `startEnrollment(method)`, `completeEnrollment(input)`, `cancelEnrollment()`
and `recoverEnrollment()`. After an uncertain begin/completion, query enrollment status; never automatically
repeat a write or redeliver a key. Lost material requires explicit cancellation before restarting. Expired/revoked/cancelled
states cannot be confirmed. Lost response disables mutation and offers result/registration status lookup even
when the first registration response never arrived. Role/version conflict requires a fresh read, the explicit
"Review updated invitation" action, and a separate confirmation of the refreshed role.
`useAuthenticatedSession()` is an explicit authority transition after ordinary login, never a silent fallback.
After a full reload without finite context, restart from the original invitation or use an authorized terminal
result read; do not persist proof/context in URL, localStorage, sessionStorage, analytics, or a global cache.

`onAccepted` receives the safe committed journey, not an access token. Host navigation/callback failure is shown
separately and does not undo success. No automatic success navigation occurs; any configured destination has an
explicit button. The component uses existing appearance/locale/light/dark/system conventions.

### Recovering a security result after sign-in expires

If a known MFA operation has an uncertain result and a status request returns 401, the shared
AccountCenter/Dialog/Panel/Headless store clears authentication, proofs, setup keys, codes and pending
authorizations immediately. Only `state.recoveryReceipt` remains: a read-only reference bound to the
issuer, mode, user, Application and Client, expiring at the original operation deadline. It is not an
operation or permission to write. Explicit logout, client disposal, a different authenticated owner or
expiry discards it.

The panel offers **Sign in again**, then **Check this operation**. `onReauthenticate` receives only
`{ref, type}`; without that callback the normal configured login runs. For a navigation handoff, this
explicit action stores only the safe receipt in a scoped `sessionStorage` key. A new client can recover
it after navigation, but never automatically queries or repeats a write. Normal in-memory usage does
not persist it. A host that deliberately disposes the old client discards the receipt, including this
handoff; ordinary full-page navigation is supported without retaining a disposed client.
If browser policy blocks session storage, ordinary in-memory operation and cleanup still work;
`prepareReauthentication()` fails explicitly instead of starting navigation with a lost receipt.
The host may sign in within the same live client and explicitly query its in-memory receipt.

Headless hosts call `actions.prepareReauthentication()` before their explicit login, then
`actions.query()` after the same owner's current-user view is authenticated. Only a matching terminal
response is adopted; fresh-session pending results cannot restore write authority. All mutation
actions remain blocked until acknowledgement or `actions.discardReceipt()`. Discard only forgets
local tracking; it does not cancel the server operation. Acknowledging a recovered old
`REAUTHENTICATE` result does not sign out the newly authenticated session. Lost recovery-code
plaintext remains unavailable; a status read never redelivers secrets.

### Automatic Provider return and recovery migration

Embedded and Dialog use the same `useAuthFlow` actions as Custom. With `providerNavigation="popup"`, their Provider button automatically awaits and completes the return. Custom calls `actions.signInWithProvider(provider.id)` from its button. Remove former “I have signed in”, “continue login” and `AuthProviderWindow.callback()` controls. The low-level `AuthProviderWindow.start(authorize)` now resolves the callback URL, rather than resolving as soon as navigation starts.

For full-page navigation, use `actions.startProvider(id)` and navigate to its returned URL. Mount the same Client's `useAuthFlow` on the registered callback route; it automatically consumes only a matching CUSTOM pending issuer/Client/redirect/state/transaction. `autoProviderCallback: false` opts out for an explicitly host-owned route. HOSTED callbacks remain with `handleRedirectCallback`; CUSTOM auto-detection never consumes HOSTED pending context or arbitrary URL parameters. In server_session mode automatic return is limited to the exact configured `sessionProviderReturnUri`; the BFF owns protocol validation and Cookie state.

Popup callback pages may mount the same hook: the SDK recognizes its named popup and leaves exchange to the original window. No postMessage/broadcast completion channel is accepted. Same-origin return and a live opener are required. A provider that removes opener ownership (for example through an incompatible COOP policy) requires full-page redirect integration. Do not add a manual completion button as a workaround.

Use `state.pending !== null` for ordinary busy; keep the form and its required challenges visible. A final login failure records the typed `state.error`, ends the failed attempt and restores the normal form. If that attempt already installed OAuth tokens but required profile/permission reads failed, the hook clears its local session immediately and attempts remote revocation without waiting for it. Failed or slow revocation never blocks another login; local cleanup does not confirm that the IAM session or upstream SSO session ended. No success callback is emitted before both reads succeed. Hosts render the error beside their normal form and let the user submit a new login; do not add a separate account-loading/retry/logout screen.

Remove `state.recovery`, `retrySessionViews()`, `completionPending` and `retryCompletion()` from older unpublished integrations; no compatibility aliases are shipped. `reset()` is optional navigation, never a prerequisite after a failed login. An uncertain completion receives at most one automatic original-key reconciliation. A sent code is exchanged at most once, even if its response is lost. General `fetchPermissions()` for an existing session keeps its separate explicit read/error contract; this failure cleanup belongs to `useAuthFlow` login attempts.

MFA and pending registration verification remain explicit user challenges. Reset cannot abandon live pending registration or erase an independently authenticated account. Each hook attempt and Client generation owns its asynchronous work; closing/unmounting/restarting discards old returns. Tokens remain memory-only by default. External hosts using an older vendored bundle (including DomainHub) need a separate package upgrade and removal of their old manual Provider controls and login-recovery screens; this SDK change does not update those hosts.
